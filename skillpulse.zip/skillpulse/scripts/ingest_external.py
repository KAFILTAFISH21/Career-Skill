"""Stage 1 - Bring in real data: Kaggle job postings, Kaggle resumes, O*NET and ESCO.

Download the files yourself (Kaggle needs a free account; O*NET and ESCO are
free downloads), put them in data/external/, then run one of:

  # Job descriptions, e.g. Kaggle "LinkedIn Job Postings" (postings.csv)
  python -m scripts.ingest_external jobs data/external/postings.csv --title-col title --text-col description

  # Labelled resumes: any CSV with CV text and a 0/1 outcome column
  # (e.g. your institution's placement records joined to CVs)
  python -m scripts.ingest_external resumes data/external/resumes.csv --text-col resume_text \
        --role-col target_role --label-col placed

  # Enrich the taxonomy with O*NET "Technology Skills.txt" and ESCO "skills_en.csv"
  python -m scripts.ingest_external taxonomy --onet "data/external/Technology Skills.txt" --esco data/external/skills_en.csv

Then retrain:  python -m scripts.train
"""
import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.config import RAW_JOBS, RAW_RESUMES, TAXONOMY_SKILLS  # noqa: E402
from app.taxonomy import load_taxonomy  # noqa: E402


def map_title(title, roles):
    t = str(title).lower()
    for rid, r in roles.items():
        if any(k in t for k in r["title_keywords"]):
            return rid
    return None


def ingest_jobs(a):
    tax = load_taxonomy()
    df = pd.read_csv(a.path, usecols=[a.title_col, a.text_col]).dropna()
    df["role_id"] = df[a.title_col].map(lambda t: map_title(t, tax.roles))
    df = df.dropna(subset=["role_id"])
    if a.max_per_role:
        df = pd.concat([g.sample(min(len(g), a.max_per_role), random_state=0) for _, g in df.groupby("role_id")])
    out = pd.DataFrame({"job_id": [f"K{i:06d}" for i in range(len(df))], "role_id": df.role_id.values,
                        "title": df[a.title_col].values, "company": "", "description": df[a.text_col].values,
                        "source": Path(a.path).name})
    if a.append and RAW_JOBS.exists():
        out = pd.concat([pd.read_csv(RAW_JOBS), out], ignore_index=True)
    out.to_csv(RAW_JOBS, index=False)
    print(out.role_id.value_counts().to_string())
    print(f"Wrote {len(out)} job descriptions -> {RAW_JOBS}")


def ingest_resumes(a):
    tax = load_taxonomy()
    df = pd.read_csv(a.path)
    roles = df[a.role_col].map(lambda r: r if r in tax.roles else map_title(r, tax.roles))
    out = pd.DataFrame({"resume_id": [f"X{i:06d}" for i in range(len(df))], "target_role": roles,
                        "resume_text": df[a.text_col], "true_skills": "", "shortlisted": df[a.label_col].astype(int),
                        "source": Path(a.path).name}).dropna(subset=["target_role", "resume_text"])
    out.to_csv(RAW_RESUMES, index=False)
    print(f"Wrote {len(out)} labelled resumes ({out.shortlisted.mean():.0%} positive) -> {RAW_RESUMES}")


def enrich_taxonomy(a):
    tax = load_taxonomy()
    df = pd.read_csv(TAXONOMY_SKILLS).fillna("")
    alias_index = {}
    for sid, s in tax.skills.items():
        for t in [s.name] + s.aliases:
            alias_index[t.lower()] = sid
    added = 0
    if a.onet:
        onet = pd.read_csv(a.onet, sep="\t")
        for r in onet.itertuples():
            ex = str(r.Example).lower()
            sid = alias_index.get(ex) or next((alias_index[k] for k in sorted(alias_index, key=len, reverse=True)
                                                   if len(k) > 2 and f" {k} " in f" {ex} "), None)
            if sid:
                i = df.index[df.skill_id == sid][0]
                if not df.at[i, "onet_ref"]:
                    df.at[i, "onet_ref"] = str(getattr(r, "_4", "") or "")  # Commodity Code
                if a.add_aliases and ex not in alias_index and len(ex) < 40:
                    df.at[i, "aliases"] += "|" + ex
                    alias_index[ex] = sid
                    added += 1
    if a.esco:
        esco = pd.read_csv(a.esco).fillna("")
        for r in esco.itertuples():
            labels = [r.preferredLabel.lower()] + [x.strip().lower() for x in str(r.altLabels).split("\n") if x.strip()]
            sid = next((alias_index[l] for l in labels if l in alias_index), None)
            if sid:
                i = df.index[df.skill_id == sid][0]
                if not df.at[i, "esco_ref"]:
                    df.at[i, "esco_ref"] = r.conceptUri
    df.to_csv(TAXONOMY_SKILLS, index=False)
    print(f"Taxonomy updated: {int((df.onet_ref != '').sum())} skills linked to O*NET, "
          f"{int((df.esco_ref != '').sum())} to ESCO, {added} aliases added -> {TAXONOMY_SKILLS}")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    j = sub.add_parser("jobs")
    j.add_argument("path")
    j.add_argument("--title-col", default="title")
    j.add_argument("--text-col", default="description")
    j.add_argument("--max-per-role", type=int, default=2000)
    j.add_argument("--append", action="store_true", help="add to the existing job file instead of replacing it")
    r = sub.add_parser("resumes")
    r.add_argument("path")
    r.add_argument("--text-col", default="resume_text")
    r.add_argument("--role-col", default="target_role")
    r.add_argument("--label-col", default="placed")
    t = sub.add_parser("taxonomy")
    t.add_argument("--onet")
    t.add_argument("--esco")
    t.add_argument("--add-aliases", action="store_true")
    a = p.parse_args()
    {"jobs": ingest_jobs, "resumes": ingest_resumes, "taxonomy": enrich_taxonomy}[a.cmd](a)


if __name__ == "__main__":
    main()
