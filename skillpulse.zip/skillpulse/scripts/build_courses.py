"""Build data/taxonomy/courses.csv: learning resources mapped to every taxonomy skill.

Each skill gets search links on major MOOC platforms (always valid, always
current) plus specific free Kaggle Learn courses where one exists. Curate or
extend the CSV by hand; the recommender reads whatever is in it.
"""
import sys
from pathlib import Path
from urllib.parse import quote_plus

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.config import COURSES  # noqa: E402
from app.taxonomy import load_taxonomy  # noqa: E402

KAGGLE = {
    "python": ("Python", "python"), "pandas": ("Pandas", "pandas"),
    "machine_learning": ("Intro to Machine Learning", "intro-to-machine-learning"),
    "feature_engineering": ("Feature Engineering", "feature-engineering"),
    "sql": ("Intro to SQL", "intro-to-sql"), "data_visualization": ("Data Visualization", "data-visualization"),
    "deep_learning": ("Intro to Deep Learning", "intro-to-deep-learning"),
    "computer_vision": ("Computer Vision", "computer-vision"), "data_cleaning": ("Data Cleaning", "data-cleaning"),
}


def main():
    tax = load_taxonomy()
    rows = []
    for sid, s in tax.skills.items():
        q = quote_plus(s.name)
        if sid in KAGGLE:
            title, slug = KAGGLE[sid]
            rows.append({"skill_id": sid, "provider": "Kaggle Learn", "title": title,
                         "url": f"https://www.kaggle.com/learn/{slug}", "est_hours": 5, "cost": "Free"})
        rows += [
            {"skill_id": sid, "provider": "Coursera", "title": f"{s.name} courses and specialisations",
             "url": f"https://www.coursera.org/search?query={q}", "est_hours": 3 * s.hours_per_level, "cost": "Free to audit"},
            {"skill_id": sid, "provider": "edX", "title": f"{s.name} courses",
             "url": f"https://www.edx.org/search?q={q}", "est_hours": 3 * s.hours_per_level, "cost": "Free to audit"},
            {"skill_id": sid, "provider": "freeCodeCamp (YouTube)", "title": f"{s.name} full tutorial",
             "url": f"https://www.youtube.com/@freecodecamp/search?query={q}", "est_hours": 2 * s.hours_per_level, "cost": "Free"},
        ]
    pd.DataFrame(rows).to_csv(COURSES, index=False)
    print(f"Wrote {len(rows)} course links -> {COURSES}")


if __name__ == "__main__":
    main()
