"""Run the full training and evaluation pipeline.

    python -m scripts.train            # uses data/raw/*.csv (generates the sample if missing)

Steps
  1. Load taxonomy, job descriptions and labelled resumes
  2. Preprocess + extract skills from every JD and CV with spaCy
  3. Embed the taxonomy with Sentence-BERT
  4. Build role requirement profiles from the JDs
  5. Engineer features (gap analysis per CV) and train XGBoost + baselines
  6. Evaluate: model metrics, cross-validation, NLP extraction quality
  7. Save artifacts/ (model, embeddings, profiles) and reports/ (JSON + charts)
"""
import json
import sys
import time
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.config import COURSES, RAW_JOBS, RAW_RESUMES, REPORTS  # noqa: E402
from app.embeddings import SkillEmbedder  # noqa: E402
from app.features import FEATURES, build_features  # noqa: E402
from app.model import ReadinessModel  # noqa: E402
from app.nlp import ResumeParser  # noqa: E402
from app.role_profiles import build_role_profiles, save_profiles  # noqa: E402
from app.taxonomy import load_taxonomy  # noqa: E402

REF_DATE = date(2026, 10, 1)  # reference date the sample CVs were written against


def log(msg, t0=[time.time()]):
    print(f"[{time.time() - t0[0]:6.1f}s] {msg}", flush=True)


def nlp_evaluation(parsed, resumes):
    """Micro precision/recall/F1 of skill extraction against ground-truth skills, plus field accuracy."""
    tp = fp = fn = 0
    per_skill = {}
    for p, (_, r) in zip(parsed, resumes.iterrows()):
        truth = set(str(r["true_skills"]).split("|")) - {""}
        pred = set(p["skills"])
        tp += len(pred & truth)
        fp += len(pred - truth)
        fn += len(truth - pred)
        for s in truth | pred:
            d = per_skill.setdefault(s, [0, 0, 0])
            d[0] += s in pred and s in truth
            d[1] += s in pred and s not in truth
            d[2] += s in truth and s not in pred
    prec, rec = tp / (tp + fp), tp / (tp + fn)
    out = {"skill_extraction": {"precision": prec, "recall": rec, "f1": 2 * prec * rec / (prec + rec),
                                "true_positives": tp, "false_positives": fp, "false_negatives": fn}}
    if "true_years" in resumes:
        out["field_accuracy"] = {
            "years_experience_mae": float(np.mean([abs(p["years_experience"] - y) for p, y in zip(parsed, resumes.true_years)])),
            "internships_exact": float(np.mean([p["internships"] == y for p, y in zip(parsed, resumes.true_internships)])),
            "projects_exact": float(np.mean([p["projects"] == y for p, y in zip(parsed, resumes.true_projects)])),
            "certifications_exact": float(np.mean([p["certifications"] == y for p, y in zip(parsed, resumes.true_certifications)])),
            "degree_level_exact": float(np.mean([p["degree_level"] == y for p, y in zip(parsed, resumes.true_degree_level)])),
            "degree_field_exact": float(np.mean([p["degree_field"] == y for p, y in zip(parsed, resumes.true_field)])),
        }
    worst = sorted(((s, v[0] / max(1, v[0] + v[1] + v[2])) for s, v in per_skill.items() if sum(v) >= 20), key=lambda kv: kv[1])[:5]
    out["hardest_skills"] = [{"skill_id": s, "jaccard": round(j, 3)} for s, j in worst]
    return out


def save_charts(meta, nlp_eval):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    fi = meta["feature_importance"]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.barh([f["label"] for f in fi][::-1], [f["gain_share"] for f in fi][::-1], color="#2F45C6")
    ax.set_xlabel("Share of total gain")
    ax.set_title("XGBoost feature importance")
    fig.tight_layout()
    fig.savefig(REPORTS / "feature_importance.png", dpi=150)

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.plot(meta["roc_curve"]["fpr"], meta["roc_curve"]["tpr"], color="#2F45C6",
            label=f"XGBoost (AUC {meta['test_metrics']['XGBoost']['roc_auc']:.3f})")
    ax.plot([0, 1], [0, 1], "--", color="#999")
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("ROC curve - held-out test set")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(REPORTS / "roc_curve.png", dpi=150)

    cm = meta["test_metrics"]["XGBoost"]["confusion_matrix"]
    fig, ax = plt.subplots(figsize=(4.2, 3.8))
    m = np.array([[cm["tn"], cm["fp"]], [cm["fn"], cm["tp"]]])
    ax.imshow(m, cmap="Blues")
    for (i, j), v in np.ndenumerate(m):
        ax.text(j, i, str(v), ha="center", va="center", fontsize=13)
    ax.set_xticks([0, 1], ["Not ready", "Ready"])
    ax.set_yticks([0, 1], ["Not ready", "Ready"])
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion matrix - XGBoost")
    fig.tight_layout()
    fig.savefig(REPORTS / "confusion_matrix.png", dpi=150)

    lc = meta["learning_curve"]
    fig, ax = plt.subplots(figsize=(6, 3.8))
    ax.plot(lc["train"], label="train")
    ax.plot(lc["validation"], label="validation")
    ax.axvline(meta["best_iteration"], ls=":", color="#999")
    ax.set_xlabel("Boosting round")
    ax.set_ylabel("Log loss")
    ax.set_title("XGBoost learning curve")
    ax.legend()
    fig.tight_layout()
    fig.savefig(REPORTS / "learning_curve.png", dpi=150)
    plt.close("all")


def main():
    REPORTS.mkdir(exist_ok=True)
    if not RAW_JOBS.exists() or not RAW_RESUMES.exists():
        log("No raw data found - generating the sample corpus")
        from scripts.generate_sample_data import main as gen
        gen()
    if not COURSES.exists():
        from scripts.build_courses import main as build_courses
        build_courses()

    tax = load_taxonomy()
    jobs, resumes = pd.read_csv(RAW_JOBS), pd.read_csv(RAW_RESUMES)
    log(f"Loaded {len(jobs)} job descriptions, {len(resumes)} resumes, {len(tax.skills)} skills")

    parser = ResumeParser(tax)
    log(f"spaCy pipeline: {parser.nlp.pipe_names} (statistical NER: {parser.statistical_ner})")

    emb = SkillEmbedder.build(tax)
    emb.save()
    log(f"Embedded taxonomy with {emb.backend} -> {emb.matrix.shape}")

    profiles = build_role_profiles(jobs, parser)
    save_profiles(profiles)
    log("Built role profiles: " + ", ".join(f"{p['title']} ({len(p['skills'])} skills)" for p in profiles.values()))

    parsed = [parser.parse(t, today=REF_DATE) for t in resumes.resume_text]
    log("Parsed all resumes")
    nlp_eval = nlp_evaluation(parsed, resumes)
    log(f"NLP skill extraction F1 = {nlp_eval['skill_extraction']['f1']:.3f}")

    rows = []
    for p, rid in zip(parsed, resumes.target_role):
        p = {**p, "skills": {k: v["level"] for k, v in p["skills"].items()}}
        feats, _ = build_features(p, profiles[rid], emb)
        rows.append(feats)
    X = pd.DataFrame(rows)[FEATURES]
    y = resumes["shortlisted"].values
    X.assign(target_role=resumes.target_role, shortlisted=y).to_csv(REPORTS / "features.csv", index=False)
    log("Engineered features for every resume")

    model = ReadinessModel.train(X, y)
    model.save()
    meta = model.meta
    for name, m in meta["test_metrics"].items():
        log(f"{name:20s} acc {m['accuracy']:.3f}  prec {m['precision']:.3f}  rec {m['recall']:.3f}  F1 {m['f1']:.3f}  AUC {m['roc_auc']:.3f}")

    report = {
        "generated": date.today().isoformat(),
        "data": {"job_descriptions": len(jobs), "resumes": len(resumes), "skills": len(tax.skills),
                 "roles": len(profiles), "source": sorted(set(jobs.get("source", ["unknown"])) | set(resumes.get("source", ["unknown"])))},
        "embedding_backend": emb.backend,
        "statistical_ner": parser.statistical_ner,
        "readiness_model": {k: meta[k] for k in ["threshold", "best_iteration", "split", "test_metrics", "cv_metrics",
                                                  "feature_importance", "roc_curve"]},
        "nlp": nlp_eval,
    }
    (REPORTS / "evaluation.json").write_text(json.dumps(report, indent=2))
    save_charts(meta, nlp_eval)
    log(f"Saved report and charts to {REPORTS}")


if __name__ == "__main__":
    main()
