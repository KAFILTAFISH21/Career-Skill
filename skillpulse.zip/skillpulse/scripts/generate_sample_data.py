"""Stage 1 (sample) - Generate a labelled sample corpus so the pipeline runs out of the box.

Produces:
  data/raw/job_descriptions.csv  ~1,350 job postings across 9 roles
  data/raw/resumes.csv           4,000 CVs with ground-truth skills and a
                                 shortlisted / not-shortlisted label

The texts are written in natural CV / JD language using the taxonomy's
synonyms, so the NLP stage has real work to do. The label comes from a hidden
scoring rule with noise; the model never sees that rule, only features the
NLP pipeline extracts from the text.

Replace these files with real data via scripts/ingest_kaggle.py.
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.config import RAW_JOBS, RAW_RESUMES, SEED  # noqa: E402
from app.taxonomy import load_taxonomy  # noqa: E402

REF_YEAR, REF_MONTH = 2026, 10
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
COMPANIES = ["Acme Analytics Ltd", "Savanna Tech", "Bluewave Systems", "Northgate Bank", "Kilima Logistics",
             "Pinecrest Health", "Orbit Telecom", "Greenfield Insurance", "Lakeside Retail", "Summit Consulting",
             "Mara Fintech", "Coastline Energy", "Uptown Media", "Highland Software", "Delta Agritech"]
UNIVERSITIES = ["City University", "Lakeside Technical University", "Riverside University",
                "Highlands University of Science", "Coastal Polytechnic"]
FIRST = ["Aisha", "Brian", "Cynthia", "David", "Esther", "Felix", "Grace", "Hassan", "Irene", "James", "Kevin",
         "Lucy", "Mercy", "Nathan", "Olivia", "Peter", "Rose", "Samuel", "Tabitha", "Victor", "Wanjiru", "Yusuf"]
LAST = ["Otieno", "Kamau", "Mwangi", "Achieng", "Njoroge", "Wambui", "Kiprop", "Mutua", "Omondi", "Chebet",
        "Smith", "Patel", "Mohamed", "Ali", "Hussein", "Njeri", "Kariuki", "Barasa"]
FIELD_NAMES = {"computer science": "Computer Science", "information technology": "Information Technology",
               "software engineering": "Software Engineering", "data science": "Data Science",
               "statistics": "Statistics", "mathematics": "Mathematics", "economics": "Economics",
               "business": "Business Administration", "commerce": "Commerce", "engineering": "Electrical Engineering",
               "cybersecurity": "Cybersecurity", "management": "Management", "accounting": "Accounting",
               "finance": "Finance"}
UNRELATED = ["accounting", "finance", "management", "economics", "business"]


def sigmoid(z):
    return 1 / (1 + np.exp(-z))


def alias(rng, tax, sid):
    s = tax.skills[sid]
    options = [s.name] + s.aliases
    return options[rng.integers(len(options))]


# --------------------------------------------------------------------------- job descriptions
def make_jobs(rng, tax, per_role=150):
    rows = []
    for rid, role in tax.roles.items():
        for i in range(per_role):
            core = [s for s in role["core"] if rng.random() < 0.85]
            opt = [s for s in role["optional"] if rng.random() < 0.35]
            noise = [s for s in tax.skills if s not in role["core"] + role["optional"] and rng.random() < 0.012]
            years = max(0, int(role["min_years"] + rng.integers(-1, 3)))
            field = FIELD_NAMES[role["related_fields"][rng.integers(len(role["related_fields"]))]]
            title = role["title"]
            company = COMPANIES[rng.integers(len(COMPANIES))]
            req_lines = [f"- {['Strong knowledge of', 'Hands-on experience with', 'Proficiency in', 'Solid understanding of', 'Working knowledge of'][rng.integers(5)]} {alias(rng, tax, s)}" for s in core]
            lines = [f"{company} is hiring a {title}.",
                     "About the role: you will join a growing team and deliver high-impact work for our clients.",
                     "Requirements:",
                     f"- {years}+ years of relevant experience" if years else "- Fresh graduates are welcome to apply",
                     f"- Bachelor's degree in {field} or a related field", *req_lines]
            if opt or noise:
                lines.append("Nice to have: " + ", ".join(alias(rng, tax, s) for s in opt + noise))
            rows.append({"job_id": f"J{len(rows) + 1:05d}", "role_id": rid, "title": title, "company": company,
                         "description": "\n".join(lines), "source": "synthetic-sample"})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- resumes
def date_range(rng, months_back_end, length):
    end_abs = REF_YEAR * 12 + REF_MONTH - 1 - months_back_end
    start_abs = end_abs - length + 1
    s = f"{MONTHS[start_abs % 12]} {start_abs // 12}"
    e = "Present" if months_back_end == 0 else f"{MONTHS[end_abs % 12]} {end_abs // 12}"
    return f"{s} - {e}"


def make_resume(rng, tax, i):
    rid = list(tax.roles)[rng.integers(len(tax.roles))]
    role = tax.roles[rid]
    a = rng.normal()
    same_cat = lambda sid: [x for x in tax.skills if tax.skills[x].category == tax.skills[sid].category and x != sid]

    true = set(s for s in role["core"] if rng.random() < sigmoid(0.4 + 1.3 * a + rng.normal(0, 0.6)))
    true |= set(s for s in role["optional"] if rng.random() < sigmoid(-0.9 + 0.9 * a))
    for s in role["core"]:  # sometimes a neighbouring skill instead of the exact one (tests semantic matching)
        if s not in true and rng.random() < 0.25:
            alt = same_cat(s)
            if alt:
                true.add(alt[rng.integers(len(alt))])
    true |= set(s for s in tax.skills if rng.random() < 0.03)
    if rng.random() < 0.7:
        true |= {"communication", "teamwork", "problem_solving"} & set(s for s in tax.skills if rng.random() < 0.5)

    years = max(0.0, round(rng.normal(0.4 + 0.7 * a, 1.0) * 2) / 2)
    internships = int(np.clip(round(rng.normal(0.8 + 0.4 * a, 0.7)), 0, 3))
    projects = int(np.clip(round(rng.normal(2.5 + 1.0 * a, 1.4)), 0, 7))
    certs = int(np.clip(round(rng.normal(1.2 + 0.5 * a, 1.0)), 0, 5))
    level = 3 if rng.random() < 0.12 + 0.05 * a else (1 if rng.random() < 0.08 else 2)
    related = rng.random() < 0.75
    field = (role["related_fields"][rng.integers(len(role["related_fields"]))] if related
             else UNRELATED[rng.integers(len(UNRELATED))])
    related = field in role["related_fields"]
    gpa4 = float(np.clip(3.0 + 0.35 * a + rng.normal(0, 0.3), 2.0, 4.0))
    show_gpa = rng.random() < 0.8

    # ---- hidden labelling rule (never shown to the model)
    core_cov = len(true & set(role["core"])) / len(role["core"])
    opt_cov = len(true & set(role["optional"])) / len(role["optional"])
    exp_term = min(years - role["min_years"], 3)
    z = (3.2 * (core_cov - 0.6) + 1.2 * (opt_cov - 0.3) + 0.45 * exp_term + 0.55 * internships + 0.2 * projects
         + 0.12 * certs + 0.7 * related + 0.35 * (level >= 3) + 1.2 * (gpa4 / 4 - 0.75)
         + (0.8 if core_cov > 0.8 and (internships > 0 or years >= 1) else 0) - 1.0)

    # ---- write the CV text
    name = f"{FIRST[rng.integers(len(FIRST))]} {LAST[rng.integers(len(LAST))]}"
    skill_list = list(true)
    rng.shuffle(skill_list)
    in_section = skill_list[: max(1, int(len(skill_list) * 0.7))]
    elsewhere = skill_list[len(in_section):]
    cue = lambda: ["", "", "Advanced ", "Proficient in ", "Basic ", "Familiar with "][rng.integers(6)]

    lines = [name, "Summary",
             f"{['Motivated', 'Detail-oriented', 'Results-driven', 'Curious'][rng.integers(4)]} graduate seeking an "
             f"entry-level position."]
    if years >= 1:
        lines[-1] += f" {years:g} years of professional experience."
    lines += ["Skills"] + [f"- {cue()}{alias(rng, tax, s)}" for s in in_section]

    lines.append("Experience")
    pool = list(elsewhere)
    back = 0
    if years > 0:
        months = int(years * 12)
        tool = alias(rng, tax, pool.pop()) if pool else "internal tools"
        lines.append(f"- Graduate Trainee, {COMPANIES[rng.integers(len(COMPANIES))]} ({date_range(rng, 0, months)}): delivered features using {tool}")
        back = months + 1
    for _ in range(internships):
        length = int(rng.integers(3, 7))
        tool = alias(rng, tax, pool.pop()) if pool else alias(rng, tax, skill_list[rng.integers(len(skill_list))])
        lines.append(f"- Intern, {COMPANIES[rng.integers(len(COMPANIES))]} ({date_range(rng, back, length)}): supported the team using {tool}")
        back += length + int(rng.integers(1, 4))
    if years == 0 and internships == 0:
        lines.append("- Volunteer, campus technology club")

    lines.append("Projects")
    for p in range(projects):
        used = [alias(rng, tax, pool.pop())] if pool else []
        used.append(alias(rng, tax, skill_list[rng.integers(len(skill_list))]))
        lines.append(f"- Project {p + 1}: built a {['dashboard', 'web app', 'prediction model', 'automation script', 'API', 'reporting tool'][rng.integers(6)]} using {' and '.join(used)}")
    if pool:  # make sure every true skill is mentioned somewhere
        lines.insert(3, "Coursework included " + ", ".join(alias(rng, tax, s) for s in pool) + ".")

    lines.append("Education")
    deg = {1: "Diploma in", 2: ["BSc", "Bachelor of Science in", "BCom"][rng.integers(3)], 3: "MSc"}[level]
    if deg == "BCom":
        deg = "Bachelor of Commerce in"
    edu = f"{deg} {FIELD_NAMES.get(field, field.title())}, {UNIVERSITIES[rng.integers(len(UNIVERSITIES))]}, {REF_YEAR - int(rng.integers(0, 3))}"
    if show_gpa:
        edu += f". GPA {gpa4:.2f}/4.0" if rng.random() < 0.6 else f". CGPA {gpa4 * 2.5:.1f}/10"
    lines.append(edu)
    if certs:
        lines.append("Certifications")
        for _ in range(certs):
            lines.append(f"- {['Google', 'Microsoft', 'Oracle', 'Cisco', 'IBM', 'Coursera'][rng.integers(6)]} certificate in {alias(rng, tax, skill_list[rng.integers(len(skill_list))])}")

    return {"resume_id": f"R{i + 1:05d}", "target_role": rid, "resume_text": "\n".join(lines),
            "true_skills": "|".join(sorted(true)), "true_years": years, "true_internships": internships,
            "true_projects": projects, "true_certifications": certs, "true_degree_level": level,
            "true_field": field, "_z": z}


def main(n_resumes=4000, per_role=150):
    rng = np.random.default_rng(SEED)
    tax = load_taxonomy()
    jobs = make_jobs(rng, tax, per_role)
    res = pd.DataFrame([make_resume(rng, tax, i) for i in range(n_resumes)])
    z = res.pop("_z").values
    res["shortlisted"] = (rng.random(len(res)) < sigmoid(z - z.mean())).astype(int)
    res["source"] = "synthetic-sample"
    RAW_JOBS.parent.mkdir(parents=True, exist_ok=True)
    jobs.to_csv(RAW_JOBS, index=False)
    res.to_csv(RAW_RESUMES, index=False)
    print(f"Wrote {len(jobs)} job descriptions -> {RAW_JOBS}")
    print(f"Wrote {len(res)} resumes ({res.shortlisted.mean():.0%} shortlisted) -> {RAW_RESUMES}")


if __name__ == "__main__":
    main()
