Put downloaded source files here (they are git-ignored):

- Kaggle job postings, e.g. LinkedIn Job Postings (`postings.csv`)
- Labelled resumes / placement records (`resumes.csv`)
- O*NET Database: `Technology Skills.txt` (https://www.onetcenter.org/database.html)
- ESCO classification: `skills_en.csv` (https://esco.ec.europa.eu/en/use-esco/download)

Then run `python -m scripts.ingest_external --help`.
