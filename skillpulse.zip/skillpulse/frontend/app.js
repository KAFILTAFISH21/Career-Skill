/* SkillPulse dashboard: talks to the FastAPI backend at /api */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const pct = (v) => Math.round(v * 100);
const tone = (p) => (p >= 0.75 ? "good" : p >= 0.5 ? "warn" : "bad");

const FIELDS = ["computer science", "information technology", "software engineering", "data science", "statistics",
  "mathematics", "economics", "business", "commerce", "cybersecurity", "engineering", "management", "accounting", "finance"];

const SAMPLE_CV = `Aisha Kamau
Summary
Analytical graduate seeking an entry-level data role. Comfortable turning messy data into clear reports.
Skills
- Advanced Excel (pivot tables, XLOOKUP)
- SQL (PostgreSQL)
- Python and pandas
- Data visualization with Tableau
- Basic statistics
- Strong communication skills
Experience
- Finance Intern, Lakeside Retail (Jan 2025 - Jun 2025): automated weekly sales reports in Excel and cleaned supplier data
- Student Assistant, City University Library (Sep 2023 - Dec 2024): maintained records in a SQL database
Projects
- Sales dashboard: built an interactive Tableau dashboard tracking regional revenue
- Customer churn analysis: used pandas and hypothesis testing to compare customer segments
Education
Bachelor of Science in Statistics, City University, 2025. GPA 3.4/4.0
Certifications
- Google Data Analytics Certificate`;

const S = { roles: [], skills: [], skillMap: {}, chosen: {} };

async function api(path, body) {
  const r = await fetch(path, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {});
  if (!r.ok) {
    let msg = `Request failed (${r.status})`;
    try { const j = await r.json(); msg = typeof j.detail === "string" ? j.detail : msg; } catch (e) {}
    throw new Error(msg);
  }
  return r.json();
}

/* ------------------------------------------------------------------ form */
function renderChips() {
  const ids = Object.keys(S.chosen);
  $("skillChips").innerHTML = ids.length
    ? ids.map((id) => `<span class="chip">${esc(S.skillMap[id].name)}
        <select data-lvl="${id}" aria-label="Level for ${esc(S.skillMap[id].name)}">${[1, 2, 3, 4, 5].map((l) => `<option ${l === S.chosen[id] ? "selected" : ""}>${l}</option>`).join("")}</select>
        <button type="button" data-rm="${id}" aria-label="Remove ${esc(S.skillMap[id].name)}">×</button></span>`).join("")
    : `<span class="note">Extract from a CV or add skills below.</span>`;
}
$("skillChips").addEventListener("change", (e) => { if (e.target.dataset.lvl) S.chosen[e.target.dataset.lvl] = +e.target.value; });
$("skillChips").addEventListener("click", (e) => { if (e.target.dataset.rm) { delete S.chosen[e.target.dataset.rm]; renderChips(); } });
$("addSkillBtn").onclick = () => { const id = $("addSkill").value; if (id) { S.chosen[id] = S.chosen[id] || 3; renderChips(); } };
$("hours").oninput = () => ($("hoursOut").textContent = $("hours").value);
$("sampleBtn").onclick = () => { $("cv").value = SAMPLE_CV; $("role").value = "data_analyst"; extract(); };
$("extractBtn").onclick = extract;

async function extract() {
  const text = $("cv").value.trim();
  if (text.length < 20) { $("extractMsg").textContent = "Paste at least a few lines of CV text first."; return; }
  $("extractBtn").disabled = true; $("extractMsg").textContent = "Running the NLP pipeline…";
  try {
    const r = await api("/api/extract", { text });
    S.chosen = {}; r.skills.forEach((s) => (S.chosen[s.skill_id] = s.level)); renderChips();
    $("years").value = r.years_experience; $("internships").value = r.internships; $("projects").value = r.projects;
    $("certs").value = r.certifications; $("degree").value = r.degree_level;
    if (r.degree_field) $("field").value = r.degree_field;
    if (r.gpa != null) { $("gpa").value = (r.gpa * 4).toFixed(2); $("gpaScale").value = "4"; }
    $("extractMsg").textContent = `Found ${r.skills.length} skills and ${r.entities.length} entities. Review and adjust before predicting.`;
  } catch (e) { $("extractMsg").textContent = e.message; }
  $("extractBtn").disabled = false;
}

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("formError").hidden = true;
  if (!Object.keys(S.chosen).length && !$("cv").value.trim()) { showError("Add at least one skill or paste a CV."); return; }
  const gpa = parseFloat($("gpa").value);
  const body = {
    target_role: $("role").value,
    resume_text: $("cv").value.trim() || null,
    skills: Object.fromEntries(S.skillsAll.map((s) => [s.skill_id, S.chosen[s.skill_id] || 0])),
    years_experience: num("years"), internships: num("internships"), projects: num("projects"), certifications: num("certs"),
    degree_level: +$("degree").value, degree_field: $("field").value,
    gpa: isNaN(gpa) ? null : Math.min(1, gpa / +$("gpaScale").value),
    hours_per_week: +$("hours").value,
  };
  $("analyzeBtn").disabled = true; $("analyzeBtn").textContent = "Predicting…";
  try { renderResults(await api("/api/analyze", body)); }
  catch (err) { showError(err.message); }
  $("analyzeBtn").disabled = false; $("analyzeBtn").textContent = "Predict readiness";
});
const num = (id) => ($(id).value === "" ? null : +$(id).value);
function showError(m) { $("formError").textContent = m; $("formError").hidden = false; }

/* ------------------------------------------------------------------ results */
function gauge(p) {
  const r = 95, cx = 120, cy = 112, len = Math.PI * r;
  return `<svg viewBox="0 0 240 140" style="width:100%;max-width:240px" role="img" aria-label="Readiness ${pct(p)} out of 100">
    <path d="M${cx - r} ${cy} A${r} ${r} 0 0 1 ${cx + r} ${cy}" fill="none" stroke="var(--sunk)" stroke-width="18" stroke-linecap="round"/>
    <path d="M${cx - r} ${cy} A${r} ${r} 0 0 1 ${cx + r} ${cy}" fill="none" stroke="var(--${tone(p)})" stroke-width="18" stroke-linecap="round" stroke-dasharray="${len * p} ${len}"/>
    <text x="${cx}" y="${cy - 14}" text-anchor="middle" style="font:500 44px var(--f-display);fill:var(--ink)">${pct(p)}</text>
    <text x="${cx}" y="${cy + 10}" text-anchor="middle" style="font-size:10px;fill:var(--muted)">READINESS / 100</text></svg>`;
}
const STATUS = { matched: "good", "semantic match": "info", partial: "warn", missing: "bad" };

function renderResults(d) {
  const p = d.readiness.probability, g = d.gap;
  const maxC = Math.max(...d.explanation.contributions.map((c) => Math.abs(c.contribution)), 0.3);
  const top = d.role_ranking[0];
  $("results").innerHTML = `
  <section class="card"><div class="hero">
    <div style="text-align:center">${gauge(p)}<div><span class="pill ${tone(p)}">${esc(d.readiness.verdict)}</span></div></div>
    <div><div class="note">TARGET ROLE · ${d.target_role.n_postings} job postings analysed</div>
      <h2 style="font-size:1.45rem;margin:2px 0 4px">${esc(d.target_role.title)}</h2>
      <div class="muted small">XGBoost readiness probability ${(p * 100).toFixed(1)}%${top.role_id !== d.target_role.role_id && top.readiness - p > 0.05 ? ` · best-fit role right now: <b>${esc(top.title)}</b> (${pct(top.readiness)}%)` : ""}</div>
      <div class="kpis">
        <div><b>${pct(g.skill_overlap_pct)}%</b><span>Exact skill overlap</span></div>
        <div><b>${pct(g.weighted_coverage)}%</b><span>Weighted coverage</span></div>
        <div><b>${pct(g.core_coverage)}%</b><span>Core skills covered</span></div>
        <div><b>${g.semantic_similarity.toFixed(2)}</b><span>Cosine similarity</span></div>
      </div></div></div></section>

  <div class="cols">
    <section class="card"><h2>Why this score</h2><p class="sub">SHAP contributions from the XGBoost model, in log-odds. Green raises readiness, red lowers it.</p>
      <div class="bars">${d.explanation.contributions.map((c) => { const w = (Math.abs(c.contribution) / maxC) * 50;
        return `<div class="bar"><span>${esc(c.label)}</span><div class="track"><div class="mid"></div><i style="left:${c.contribution < 0 ? 50 - w : 50}%;width:${w}%;background:var(--${c.contribution < 0 ? "bad" : "good"})"></i></div><span class="num" style="text-align:right">${c.contribution > 0 ? "+" : ""}${c.contribution.toFixed(2)}</span></div>`; }).join("")}</div></section>
    <section class="card"><h2>Role ranking</h2><p class="sub">The same model scored against every role profile.</p>
      <div class="tscroll"><table><thead><tr><th>Role</th><th class="n">Coverage</th><th class="n">Similarity</th><th class="n">Readiness</th></tr></thead><tbody>
      ${d.role_ranking.map((r) => `<tr${r.role_id === d.target_role.role_id ? ' style="font-weight:600"' : ""}><td>${esc(r.title)}</td><td class="n">${pct(r.coverage)}%</td><td class="n">${r.similarity.toFixed(2)}</td><td class="n"><span class="pill ${tone(r.readiness)}">${pct(r.readiness)}%</span></td></tr>`).join("")}
      </tbody></table></div></section>
  </div>

  <section class="card"><h2>Skill gap analysis</h2><p class="sub">Requirements mined from ${d.target_role.n_postings} ${esc(d.target_role.title)} postings. Each required skill is matched to your closest skill by cosine similarity of their embeddings.</p>
    <div class="tscroll"><table><thead><tr><th>Required skill</th><th class="n">In % of jobs</th><th class="n">Importance</th><th>Status</th><th>Closest skill you have</th><th class="n">Similarity</th></tr></thead><tbody>
    ${g.skills.map((s) => `<tr><td>${esc(s.name)}${s.core ? ' <span class="pill info">core</span>' : ""}</td><td class="n">${pct(s.frequency)}%</td><td class="n">${s.importance.toFixed(2)}</td><td><span class="pill ${STATUS[s.status]}">${s.status}</span></td><td>${s.closest_user_skill ? esc(S.skillMap[s.closest_user_skill]?.name || s.closest_user_skill) : "—"}</td><td class="n">${s.similarity.toFixed(2)}</td></tr>`).join("")}
    </tbody></table></div></section>

  <section class="card"><h2>Recommended next skills</h2><p class="sub">Ranked by (1 − coverage) × importance × market demand. "Readiness gain" is the model's prediction if you reached the target level.</p>
    ${d.recommendations.length ? `<div class="recs">${d.recommendations.map((r, i) => `<article class="rec">
      <h3><span>${i + 1}. ${esc(r.skill)}</span><span class="pill ${r.impact > 0.03 ? "good" : "info"}">+${(r.impact * 100).toFixed(1)} pts</span></h3>
      <div class="note">${esc(r.category)} · in ${pct(r.frequency)}% of postings · ~${r.est_hours} h to level ${r.target_level}${r.related_skill_you_have ? ` · builds on your ${esc(S.skillMap[r.related_skill_you_have]?.name || "")}` : ""}</div>
      <div class="meter" title="Priority"><i style="width:${Math.min(100, (r.priority / d.recommendations[0].priority) * 100)}%"></i></div>
      <div class="small"><b>Project:</b> ${esc(r.project)}</div>
      <ul>${r.courses.map((c) => `<li><a href="${esc(c.url)}" target="_blank" rel="noopener">${esc(c.provider)}: ${esc(c.title)}</a> <span class="note">${esc(c.cost)}</span></li>`).join("")}</ul>
    </article>`).join("")}</div>` : "<p>No gaps: every required skill is covered. Focus on interview preparation and portfolio depth.</p>"}</section>

  ${d.learning_plan.length ? `<section class="card"><h2>Study plan</h2><p class="sub">Prerequisites first (topological sort), at ${$("hours").value} hours a week: about ${d.learning_plan[d.learning_plan.length - 1].end_week} weeks in total.</p>
    <div class="timeline">${d.learning_plan.map((s) => `<div class="tl"><div class="wk">Wk ${s.start_week}–${s.end_week}</div><div class="dot ${s.prerequisite ? "pre" : ""}"></div>
      <div class="body"><b>${esc(s.skill)}</b> <span class="note">${s.hours} h${s.prerequisite ? " · prerequisite" : ""}</span><div class="note">Milestone: ${esc(s.milestone)}</div></div></div>`).join("")}</div></section>` : ""}

  ${d.entities.length ? `<section class="card"><h2>Entities found in the CV</h2><p class="sub">spaCy named entities (SKILL and DEGREE from the entity ruler; ORG, DATE and GPE from the statistical model).</p>
    <div class="ents">${d.entities.map((e) => `<span class="ent">${esc(e.text)}<b>${e.label}</b></span>`).join("")}</div></section>` : ""}`;
  $("results").scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
}

/* ------------------------------------------------------------------ evaluation view */
function roc(curve, auc) {
  const W = 300, H = 260, pl = 36, pb = 30, pt = 10, pr = 10;
  const sx = (v) => pl + v * (W - pl - pr), sy = (v) => H - pb - v * (H - pt - pb);
  let ax = '<g class="ax">';
  for (let i = 0; i <= 4; i++) { const v = i / 4; ax += `<line x1="${sx(v)}" x2="${sx(v)}" y1="${pt}" y2="${H - pb}" stroke-dasharray="2 3"/><line x1="${pl}" x2="${W - pr}" y1="${sy(v)}" y2="${sy(v)}" stroke-dasharray="2 3"/><text x="${sx(v)}" y="${H - pb + 13}" text-anchor="middle">${v}</text><text x="${pl - 5}" y="${sy(v) + 3}" text-anchor="end">${v}</text>`; }
  ax += `<text x="${(W + pl) / 2}" y="${H - 3}" text-anchor="middle">False positive rate</text></g>`;
  const pts = curve.fpr.map((f, i) => `${sx(f).toFixed(1)},${sy(curve.tpr[i]).toFixed(1)}`).join(" ");
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:340px" role="img" aria-label="ROC curve, AUC ${auc.toFixed(3)}">${ax}
    <line x1="${sx(0)}" y1="${sy(0)}" x2="${sx(1)}" y2="${sy(1)}" stroke="var(--muted)" stroke-dasharray="4 3"/>
    <polyline points="${pts}" fill="none" stroke="var(--accent)" stroke-width="2.2"/></svg>`;
}

async function loadEval() {
  try {
    const r = await api("/api/metrics"), m = r.readiness_model, x = m.test_metrics.XGBoost.confusion_matrix;
    const maxG = m.feature_importance[0].gain_share, nlp = r.nlp.skill_extraction;
    const row = (n, v) => `<tr><td>${n}</td><td class="n">${(v.accuracy * 100).toFixed(1)}%</td><td class="n">${(v.precision * 100).toFixed(1)}%</td><td class="n">${(v.recall * 100).toFixed(1)}%</td><td class="n">${v.f1.toFixed(3)}</td><td class="n">${v.roc_auc.toFixed(3)}</td></tr>`;
    $("evalOut").innerHTML = `
    <section class="card"><h2>Readiness model</h2><p class="sub">Held-out test set of ${m.split.test} CVs (train ${m.split.train}, validation ${m.split.validation}). XGBoost decision threshold ${m.threshold.toFixed(2)}, tuned for F1 on validation. Embeddings: ${esc(r.embedding_backend)}.</p>
      <div class="tscroll"><table><thead><tr><th>Model</th><th class="n">Accuracy</th><th class="n">Precision</th><th class="n">Recall</th><th class="n">F1</th><th class="n">ROC-AUC</th></tr></thead><tbody>
      ${Object.entries(m.test_metrics).map(([k, v]) => row(k, v)).join("")}
      <tr style="color:var(--muted)">${row("XGBoost, 5-fold CV mean", Object.fromEntries(Object.entries(m.cv_metrics).map(([k, v]) => [k, v.mean]))).slice(4)}
      </tbody></table></div></section>
    <div class="cols">
      <section class="card"><h2>Feature importance</h2><p class="sub">Share of total XGBoost gain.</p><div class="bars">
        ${m.feature_importance.map((f) => `<div class="bar"><span>${esc(f.label)}</span><div class="track"><i style="left:0;width:${(f.gain_share / maxG) * 100}%;background:var(--accent)"></i></div><span class="num" style="text-align:right">${(f.gain_share * 100).toFixed(1)}%</span></div>`).join("")}</div></section>
      <section class="card"><h2>ROC curve and confusion matrix</h2><p class="sub">XGBoost on the test set.</p>
        <div class="row" style="flex-wrap:wrap;align-items:flex-start;gap:20px">${roc(m.roc_curve, m.test_metrics.XGBoost.roc_auc)}
        <div class="cm"><div class="h"></div><div class="h">Pred. ready</div><div class="h">Pred. not</div>
          <div class="h">Ready</div><div class="good num">${x.tp}</div><div class="bad num">${x.fn}</div>
          <div class="h">Not ready</div><div class="bad num">${x.fp}</div><div class="good num">${x.tn}</div></div></div></section>
    </div>
    <section class="card"><h2>NLP extraction quality</h2><p class="sub">Skills extracted from ${r.data.resumes} CVs compared with their ground-truth skill lists (micro-averaged).</p>
      <div class="kpis"><div><b>${(nlp.precision * 100).toFixed(1)}%</b><span>Precision</span></div><div><b>${(nlp.recall * 100).toFixed(1)}%</b><span>Recall</span></div><div><b>${nlp.f1.toFixed(3)}</b><span>F1</span></div><div><b>${r.data.skills}</b><span>Skills in taxonomy</span></div></div>
      ${r.nlp.field_accuracy ? `<div class="tscroll" style="margin-top:12px"><table><thead><tr><th>Field</th><th class="n">Accuracy</th></tr></thead><tbody>${Object.entries(r.nlp.field_accuracy).map(([k, v]) => `<tr><td>${k.replace(/_/g, " ")}</td><td class="n">${k.endsWith("mae") ? v.toFixed(2) + " yrs MAE" : (v * 100).toFixed(1) + "%"}</td></tr>`).join("")}</tbody></table></div>` : ""}
      <p class="note">Data source: ${esc(r.data.source.join(", "))}. ${r.data.job_descriptions} job descriptions, ${r.data.roles} roles.</p></section>`;
  } catch (e) { $("evalOut").innerHTML = `<div class="card error">${esc(e.message)}</div>`; }
}

/* ------------------------------------------------------------------ boot */
document.querySelectorAll(".tabs button").forEach((b) => b.addEventListener("click", () => {
  document.querySelectorAll(".tabs button").forEach((x) => x.setAttribute("aria-selected", x === b));
  $("view-analyze").hidden = b.dataset.view !== "analyze";
  $("view-eval").hidden = b.dataset.view !== "eval";
  if (b.dataset.view === "eval") loadEval();
}));

(async function init() {
  try {
    [S.roles, S.skillsAll] = await Promise.all([api("/api/roles"), api("/api/skills")]);
    S.skillsAll.forEach((s) => (S.skillMap[s.skill_id] = s));
    $("role").innerHTML = S.roles.map((r) => `<option value="${r.role_id}">${esc(r.title)}</option>`).join("");
    $("addSkill").innerHTML = '<option value="">Choose a skill…</option>' + [...S.skillsAll].sort((a, b) => a.name.localeCompare(b.name)).map((s) => `<option value="${s.skill_id}">${esc(s.name)}</option>`).join("");
    $("field").innerHTML = '<option value="">Not specified</option>' + FIELDS.map((f) => `<option value="${f}">${f[0].toUpperCase() + f.slice(1)}</option>`).join("");
  } catch (e) { showError("Could not reach the API: " + e.message); }
})();
