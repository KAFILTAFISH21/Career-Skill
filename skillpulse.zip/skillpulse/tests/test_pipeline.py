"""Run with:  pytest -q   (after `python -m scripts.train` has produced artifacts/)"""
from datetime import date

import pytest
from fastapi.testclient import TestClient

from app.api import app
from app.nlp import ResumeParser, clean_text
from app.recommend import learning_plan
from app.taxonomy import load_taxonomy

CV = """Jane Doe
Skills
- Advanced Python, pandas and SQL (PostgreSQL)
- Basic Tableau
Experience
- Data Intern, Acme Ltd (Jan 2025 - Jun 2025): cleaned data with pandas
- Analyst, Beta Corp (Jul 2025 - Present)
Projects
- Churn model: built a classifier with scikit-learn
Education
Bachelor of Science in Statistics, City University. GPA 3.2/4.0
Certifications
- Google Data Analytics Certificate
"""


@pytest.fixture(scope="module")
def parser():
    return ResumeParser()


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_clean_text_removes_contacts():
    t = clean_text("Email jane@x.com • call +254 712 345 678 • https://site.com")
    assert "@" not in t and "http" not in t and "712" not in t


def test_skill_extraction(parser):
    skills = parser.extract_skills(CV)
    assert {"python", "pandas", "sql", "tableau", "scikit_learn"} <= set(skills)
    assert skills["tableau"]["level"] < skills["python"]["level"]  # "basic" vs "advanced" cue


def test_full_parse(parser):
    p = parser.parse(CV, today=date(2026, 10, 1))
    assert p["internships"] == 1
    assert p["years_experience"] == pytest.approx(16 / 12, abs=0.1)
    assert p["degree_level"] == 2 and p["degree_field"] == "statistics"
    assert p["gpa"] == pytest.approx(0.8)
    assert p["projects"] == 1 and p["certifications"] == 1


def test_learning_plan_respects_prerequisites():
    tax = load_taxonomy()
    recs = [{"skill_id": "pytorch", "priority": 1.0, "est_hours": 40}]
    order = [s["skill_id"] for s in learning_plan(recs, {}, tax)]
    assert order.index("python") < order.index("machine_learning") < order.index("deep_learning") < order.index("pytorch")


def test_api_analyze(client):
    r = client.post("/api/analyze", json={"target_role": "data_analyst", "resume_text": CV})
    assert r.status_code == 200
    d = r.json()
    assert 0 <= d["readiness"]["probability"] <= 1
    assert d["gap"]["skills"] and d["role_ranking"][0]["readiness"] >= d["role_ranking"][-1]["readiness"]
    assert all(rec["status"] in ("missing", "partial") for rec in d["recommendations"])


def test_more_skills_raise_readiness(client):
    base = {"target_role": "data_analyst", "skills": {"excel": 3}, "years_experience": 0, "internships": 0,
            "projects": 1, "certifications": 0, "degree_level": 2, "degree_field": "statistics", "gpa": 0.75}
    low = client.post("/api/analyze", json=base).json()["readiness"]["probability"]
    rich = {**base, "skills": {s: 4 for s in ["excel", "sql", "power_bi", "data_visualization", "statistics", "data_cleaning"]}}
    high = client.post("/api/analyze", json=rich).json()["readiness"]["probability"]
    assert high > low


def test_api_validation(client):
    assert client.post("/api/analyze", json={"target_role": "astronaut", "skills": {"python": 3}}).status_code == 422
    assert client.post("/api/analyze", json={"target_role": "data_analyst"}).status_code == 422


def test_missing_gpa_is_valid_json(client):
    r = client.post("/api/analyze", json={"target_role": "backend_dev", "skills": {"python": 4, "sql": 3, "git": 3}})
    assert r.status_code == 200
    assert r.json()["features"]["gpa"] is None
