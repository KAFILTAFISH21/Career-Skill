"""Stage 8 - FastAPI backend serving the REST API and the dashboard frontend.

Run locally:  uvicorn app.api:app --reload
Docs:         http://localhost:8000/docs
"""
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import __version__
from .config import FRONTEND

STATE = {}


@asynccontextmanager
async def lifespan(_app):
    from .service import ReadinessService
    STATE["svc"] = ReadinessService()
    yield


app = FastAPI(title="SkillPulse API", version=__version__, lifespan=lifespan,
              description="Career readiness prediction, skill gap analysis and learning recommendations.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def svc():
    return STATE["svc"]


class ExtractRequest(BaseModel):
    text: str = Field(..., min_length=20, description="Raw CV / resume text")


class AnalyzeRequest(BaseModel):
    target_role: str = Field(..., examples=["data_analyst"])
    resume_text: Optional[str] = None
    skills: Optional[dict[str, int]] = Field(None, description="skill_id -> level 1-5 (0 removes a parsed skill)")
    years_experience: Optional[float] = Field(None, ge=0, le=50)
    internships: Optional[int] = Field(None, ge=0, le=10)
    projects: Optional[int] = Field(None, ge=0, le=30)
    certifications: Optional[int] = Field(None, ge=0, le=30)
    degree_level: Optional[int] = Field(None, ge=0, le=4)
    degree_field: Optional[str] = None
    gpa: Optional[float] = Field(None, ge=0, le=1, description="Normalised 0-1 (e.g. 3.2/4.0 = 0.8)")
    hours_per_week: float = Field(10, gt=0, le=80)
    top_n: int = Field(8, ge=1, le=20)


@app.get("/api/health")
def health():
    s = svc()
    return {"status": "ok", "version": __version__, "embedding_backend": s.emb.backend,
            "statistical_ner": s.parser.statistical_ner, "roles": len(s.profiles), "skills": len(s.tax.skills)}


@app.get("/api/roles")
def roles():
    return [{"role_id": rid, "title": p["title"], "n_postings": p["n_postings"], "min_years": p["min_years"],
             "related_fields": p["related_fields"], "skills": p["skills"]} for rid, p in svc().profiles.items()]


@app.get("/api/skills")
def skills():
    return [{"skill_id": s.id, "name": s.name, "category": s.category, "aliases": s.aliases,
             "prerequisites": s.prerequisites} for s in svc().tax.skills.values()]


@app.get("/api/skills/{skill_id}/similar")
def similar(skill_id: str, k: int = 5):
    s = svc()
    if skill_id not in s.emb.index:
        raise HTTPException(404, f"Unknown skill '{skill_id}'")
    return [{"skill_id": sid, "name": s.tax.name(sid), "similarity": sim} for sid, sim in s.emb.most_similar(skill_id, k)]


@app.post("/api/extract")
def extract(req: ExtractRequest):
    return svc().extract(req.text)


@app.post("/api/analyze")
def analyze(req: AnalyzeRequest):
    s = svc()
    if req.target_role not in s.profiles:
        raise HTTPException(422, f"Unknown target_role. Choose one of: {', '.join(s.profiles)}")
    if not req.resume_text and not req.skills:
        raise HTTPException(422, "Provide resume_text, skills, or both.")
    return s.analyze(req.model_dump())


@app.get("/api/metrics")
def metrics():
    import json
    from .config import REPORTS
    path = REPORTS / "evaluation.json"
    if not path.exists():
        raise HTTPException(404, "Run `python -m scripts.train` to produce the evaluation report.")
    return json.loads(path.read_text())


app.mount("/static", StaticFiles(directory=FRONTEND), name="static")


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(FRONTEND / "index.html")
