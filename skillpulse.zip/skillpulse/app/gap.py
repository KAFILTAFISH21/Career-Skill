"""Stage 4 - Gap analysis with cosine similarity.

Two levels of matching:
  * Profile level: cosine similarity between the user's skill vector (mean of
    their skill embeddings, weighted by proficiency) and the role vector
    (importance-weighted mean of required-skill embeddings).
  * Skill level: for each required skill, the closest user skill by cosine
    similarity decides whether it is matched exactly, covered semantically
    (e.g. TensorFlow for PyTorch), partially covered, or missing.
"""
import numpy as np

from .config import FULL_MATCH, PARTIAL_MATCH
from .embeddings import SkillEmbedder


def _cos(a, b):
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    return float(a @ b / (na * nb)) if na and nb else 0.0


def analyze_gap(user_skills: dict, role_profile: dict, emb: SkillEmbedder) -> dict:
    """user_skills: {skill_id: level 1-5}."""
    req = role_profile["skills"]
    req_ids = [r["skill_id"] for r in req]
    user_ids = [s for s in user_skills if s in emb.index]
    sims = emb.similarity(req_ids, user_ids)

    rows, credit_sum, imp_sum, core_c, core_n, exact = [], 0.0, 0.0, 0.0, 0, 0
    for i, r in enumerate(req):
        sid = r["skill_id"]
        if sid in user_skills:
            best_id, sim, status, credit = sid, 1.0, "matched", 1.0
            exact += 1
        elif user_ids:
            j = int(np.argmax(sims[i]))
            best_id, sim = user_ids[j], float(sims[i, j])
            if sim >= FULL_MATCH:
                status, credit = "semantic match", sim
            elif sim >= PARTIAL_MATCH:
                status, credit = "partial", 0.5 * (sim - PARTIAL_MATCH) / (FULL_MATCH - PARTIAL_MATCH)
            else:
                status, credit = "missing", 0.0
        else:
            best_id, sim, status, credit = None, 0.0, "missing", 0.0
        credit_sum += r["importance"] * credit
        imp_sum += r["importance"]
        if r["core"]:
            core_c += credit
            core_n += 1
        rows.append({**r, "status": status, "credit": round(credit, 3), "similarity": round(sim, 3),
                     "closest_user_skill": best_id, "current_level": user_skills.get(sid, 0)})

    if user_ids:
        w = np.array([user_skills[s] for s in user_ids], dtype=float)
        user_vec = (emb.vectors(user_ids) * w[:, None]).sum(0)
    else:
        user_vec = np.zeros(emb.matrix.shape[1])
    imp = np.array([r["importance"] for r in req])
    role_vec = (emb.vectors(req_ids) * imp[:, None]).sum(0)

    return {
        "skill_overlap_pct": exact / len(req),
        "weighted_coverage": credit_sum / imp_sum,
        "core_coverage": core_c / core_n if core_n else 0.0,
        "semantic_similarity": _cos(user_vec, role_vec),
        "skills": rows,
    }
