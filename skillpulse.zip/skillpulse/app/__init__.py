"""SkillPulse - Intelligent Career Readiness & Skill Gap Prediction Platform."""
__version__ = "1.0.0"
