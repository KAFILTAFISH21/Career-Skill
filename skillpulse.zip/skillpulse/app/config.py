"""Paths and tunable settings."""
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
TAXONOMY_SKILLS = DATA / "taxonomy" / "skills.csv"
TAXONOMY_ROLES = DATA / "taxonomy" / "roles.json"
COURSES = DATA / "taxonomy" / "courses.csv"
RAW_JOBS = DATA / "raw" / "job_descriptions.csv"
RAW_RESUMES = DATA / "raw" / "resumes.csv"
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "reports"
FRONTEND = ROOT / "frontend"

# Sentence-BERT model used for skill embeddings
SBERT_MODEL = os.getenv("SKILLPULSE_SBERT_MODEL", "all-MiniLM-L6-v2")

# Semantic matching thresholds (cosine similarity between skill embeddings)
FULL_MATCH = 0.80      # treat as the same skill
PARTIAL_MATCH = 0.55   # related skill, partial credit

# A skill counts as a role requirement if it appears in at least this share of the role's JDs
MIN_ROLE_FREQUENCY = 0.15

SEED = 42
