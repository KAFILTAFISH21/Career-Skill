"""Build data-driven role requirement profiles from job descriptions.

For each role, every job description is passed through the same NLP
extractor used for CVs. A skill's *frequency* is the share of that role's
JDs that ask for it; *importance* rescales frequency to 0-1 within the role;
*demand* is how often the skill appears across the whole job market sample.
"""
import json
import re
from collections import Counter, defaultdict

import numpy as np
import pandas as pd

from .config import ARTIFACTS, MIN_ROLE_FREQUENCY
from .nlp import ResumeParser

PROFILE_PATH = ARTIFACTS / "role_profiles.json"
YEARS_RE = re.compile(r"(\d+)\s*\+?\s*(?:years|yrs)", re.I)


def build_role_profiles(jobs: pd.DataFrame, parser: ResumeParser) -> dict:
    tax = parser.tax
    per_role, market, n_role, years = defaultdict(Counter), Counter(), Counter(), defaultdict(list)
    for r in jobs.itertuples():
        skills = parser.extract_skills(r.description)
        per_role[r.role_id].update(skills.keys())
        market.update(skills.keys())
        n_role[r.role_id] += 1
        m = YEARS_RE.search(r.description)
        years[r.role_id].append(int(m.group(1)) if m else 0)

    total = len(jobs)
    max_market = max(market.values()) if market else 1
    profiles = {}
    for rid, counts in per_role.items():
        n = n_role[rid]
        freqs = {s: c / n for s, c in counts.items() if c / n >= MIN_ROLE_FREQUENCY}
        top = max(freqs.values())
        skills = [{
            "skill_id": s, "name": tax.name(s), "frequency": round(f, 3),
            "importance": round(f / top, 3), "core": f >= 0.6,
            "demand": round(market[s] / max_market, 3), "market_share": round(market[s] / total, 3),
        } for s, f in sorted(freqs.items(), key=lambda kv: -kv[1])]
        role = tax.roles[rid]
        profiles[rid] = {
            "role_id": rid, "title": role["title"], "n_postings": n,
            "min_years": float(np.median(years[rid])), "related_fields": role["related_fields"],
            "market_share": round(n / total, 3), "skills": skills,
        }
    return profiles


def save_profiles(profiles, path=PROFILE_PATH):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(profiles, indent=2))


def load_profiles(path=PROFILE_PATH):
    return json.loads(path.read_text())
