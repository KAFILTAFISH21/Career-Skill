"""Stage 2 - Preprocessing & NLP extraction.

Text cleaning, then skill extraction with spaCy:
  * PhraseMatcher over every taxonomy alias (case-insensitive) finds skill mentions.
  * An EntityRuler adds SKILL and DEGREE entities on top of the statistical NER
    in en_core_web_sm (ORG, DATE, GPE ...), so the document carries one
    consistent set of named entities.
  * Rule-based parsers read experience, internships, projects, certifications
    and education from the CV sections.
"""
import re
import unicodedata
from datetime import date

import spacy
from spacy.matcher import PhraseMatcher
from spacy.tokens import Span
from spacy.util import filter_spans

from .taxonomy import Taxonomy, load_taxonomy

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], start=1)}
MONTH_RE = r"(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?"
RANGE_RE = re.compile(MONTH_RE + r"\s+(\d{4})\s*(?:-|–|—|to)\s*(?:" + MONTH_RE + r"\s+(\d{4})|(present|current|now|date))", re.I)
YEARS_RE = re.compile(r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years|yrs)(?:\s+of)?\s+(?:professional\s+|work\s+|industry\s+)?experience", re.I)
SECTION_HEADERS = {"summary", "profile", "skills", "technical skills", "experience", "work experience",
                   "employment", "projects", "education", "certifications", "certificates", "achievements"}
DEGREE_LEVELS = [
    (4, r"\bph\.?d\b|doctorate|doctor of"),
    (3, r"\bmaster|\bm\.?sc\b|\bmba\b|\bm\.?tech\b|\bm\.?eng\b|\bm\.?a\.?\b(?=\s+in)"),
    (2, r"\bbachelor|\bb\.?sc\b|\bb\.?eng\b|\bb\.?tech\b|\bb\.?com\b|\bb\.?a\.?\b(?=\s+in)|\bbba\b|\bbs\b"),
    (1, r"\bdiploma\b|\bhigher national\b|\bassociate degree"),
]
FIELDS = ["computer science", "information technology", "software engineering", "data science",
          "statistics", "mathematics", "economics", "business", "commerce", "cybersecurity",
          "engineering", "management", "accounting", "finance", "actuarial science"]
POSITIVE = {"advanced", "expert", "proficient", "strong", "extensive", "deep", "senior"}
NEGATIVE = {"basic", "beginner", "familiar", "exposure", "introductory", "learning", "elementary"}


def clean_text(text: str) -> str:
    """Normalise unicode, strip URLs/emails/phones and decorative bullets, keep line structure."""
    text = unicodedata.normalize("NFKC", text or "")
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"\S+@\S+\.\S+", " ", text)
    text = re.sub(r"\+?\d[\d\s().-]{8,}\d", " ", text)
    text = re.sub(r"[•●▪◦■►✓✔·]", "-", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n", text)
    return text.strip()


def split_sections(text: str) -> dict:
    sections, current = {"_top": []}, "_top"
    for line in text.splitlines():
        key = line.strip().strip(":").lower()
        if key in SECTION_HEADERS:
            current = {"technical skills": "skills", "work experience": "experience", "employment": "experience",
                       "certificates": "certifications", "profile": "summary"}.get(key, key)
            sections.setdefault(current, [])
        else:
            sections.setdefault(current, []).append(line)
    return {k: "\n".join(v).strip() for k, v in sections.items()}


class ResumeParser:
    def __init__(self, taxonomy: Taxonomy | None = None, model: str = "en_core_web_sm"):
        self.tax = taxonomy or load_taxonomy()
        try:
            self.nlp = spacy.load(model, exclude=["lemmatizer", "parser"])
            self.statistical_ner = True
        except OSError:  # model not installed: rule-based pipeline only
            self.nlp = spacy.blank("en")
            self.statistical_ner = False

        ruler_cfg = {"phrase_matcher_attr": "LOWER", "overwrite_ents": True}
        if "ner" in self.nlp.pipe_names:
            ruler = self.nlp.add_pipe("entity_ruler", before="ner", config=ruler_cfg)
        else:
            ruler = self.nlp.add_pipe("entity_ruler", config=ruler_cfg)
        patterns = []
        self.matcher = PhraseMatcher(self.nlp.vocab, attr="LOWER")
        for sid, s in self.tax.skills.items():
            terms = sorted(set([s.name.lower()] + [a.lower() for a in s.aliases]))
            patterns += [{"label": "SKILL", "pattern": t, "id": sid} for t in terms]
            self.matcher.add(sid, [self.nlp.make_doc(t) for t in terms])
        for deg in ["bachelor of science", "bachelor of technology", "bachelor of engineering", "bachelor of commerce",
                    "master of science", "master of business administration", "bsc", "msc", "mba", "phd", "diploma"]:
            patterns.append({"label": "DEGREE", "pattern": deg})
        ruler.add_patterns(patterns)

    # ------------------------------------------------------------------ skills
    def extract_skills(self, text: str, doc=None) -> dict:
        doc = doc or self.nlp(text)
        spans = filter_spans([Span(doc, s, e, label=m) for m, s, e in self.matcher(doc)])
        found = {}
        for sp in spans:
            sid = sp.label_
            ctx = {t.lower_ for t in doc[max(0, sp.start - 6): sp.end + 6]}
            cue = (1 if ctx & POSITIVE else 0) - (1 if ctx & NEGATIVE else 0)
            item = found.setdefault(sid, {"skill_id": sid, "name": self.tax.name(sid), "mentions": 0, "cue": 0, "evidence": []})
            item["mentions"] += 1
            item["cue"] += cue
            if len(item["evidence"]) < 3:
                item["evidence"].append(doc[sp.start:sp.end].text)
        for item in found.values():
            base = 3 + (1 if item["mentions"] >= 3 else 0)
            item["level"] = max(1, min(5, base + (1 if item["cue"] > 0 else -1 if item["cue"] < 0 else 0)))
            del item["cue"]
        return found

    # ------------------------------------------------------------------ full CV
    def parse(self, raw_text: str, today: date | None = None) -> dict:
        today = today or date.today()
        text = clean_text(raw_text)
        sections = split_sections(text)
        doc = self.nlp(text)
        skills = self.extract_skills(text, doc)

        work_months, intern_months, internships = 0, 0, 0
        for line in text.splitlines():
            for m in RANGE_RE.finditer(line):
                months = _months_between(m, today)
                if re.search(r"\bintern\b|internship|attachment", line, re.I):
                    intern_months += months
                    internships += 1
                else:
                    work_months += months
        stated = [float(x) for x in YEARS_RE.findall(text)]
        years = max(work_months / 12, max(stated) if stated else 0)
        if not internships:
            internships = len(re.findall(r"\bintern(?:ship)?\b|industrial attachment", sections.get("experience", ""), re.I))

        projects = _count_items(sections.get("projects", "")) or len(re.findall(r"\b(?:built|developed|created|designed)\b", text, re.I)) // 2
        certs = _count_items(sections.get("certifications", "")) or len(re.findall(r"certif", text, re.I))

        edu_text = (sections.get("education") or text).lower()
        level = next((lvl for lvl, pat in DEGREE_LEVELS if re.search(pat, edu_text)), 0)
        # prefer the subject after "in" ("Bachelor of Commerce in Finance" -> finance), then after "of"
        field = ""
        for prep in ("in", "of"):
            subject = " ".join(re.findall(rf"\b{prep}\s+([a-z &]+)", edu_text))
            field = next((f for f in FIELDS if f in subject), "")
            if field:
                break
        field = field or next((f for f in FIELDS if f in edu_text), "")
        gpa = _parse_gpa(edu_text)

        ents = [{"text": e.text, "label": e.label_} for e in doc.ents if e.label_ in {"SKILL", "DEGREE", "ORG", "DATE", "GPE"}]
        return {
            "skills": skills,
            "years_experience": round(years, 1),
            "internship_months": intern_months,
            "internships": min(internships, 5),
            "projects": min(projects, 10),
            "certifications": min(certs, 10),
            "degree_level": level,
            "degree_field": field,
            "gpa": gpa,
            "entities": ents[:60],
            "statistical_ner": self.statistical_ner,
        }


def _months_between(m, today):
    sm, sy = MONTHS[m.group(1)[:3].lower()], int(m.group(2))
    if m.group(5):
        em, ey = today.month, today.year
    else:
        em, ey = MONTHS[m.group(3)[:3].lower()], int(m.group(4))
    return max(0, (ey - sy) * 12 + em - sm + 1)


def _count_items(section):
    return sum(1 for ln in section.splitlines() if ln.strip().startswith("-") or (ln.strip() and ":" in ln))


def _parse_gpa(text):
    m = re.search(r"(?:cgpa|gpa|grade point average)[^0-9]{0,12}(\d(?:\.\d{1,2})?)\s*(?:/\s*(\d+(?:\.\d+)?))?", text)
    if m:
        v = float(m.group(1))
        scale = float(m.group(2)) if m.group(2) else (4.0 if v <= 4 else 10.0)
        return round(min(1.0, v / scale), 3)
    for pat, v in [(r"first class", 0.9), (r"second class upper|upper second|2:1", 0.75),
                   (r"second class lower|lower second|2:2", 0.6), (r"pass\b", 0.5)]:
        if re.search(pat, text):
            return v
    return None
