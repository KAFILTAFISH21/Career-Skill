"""Stage 5b & 7 - XGBoost readiness model and its evaluation."""
import json

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .config import ARTIFACTS, SEED
from .features import FEATURE_LABELS, FEATURES

MODEL_PATH = ARTIFACTS / "readiness_xgb.json"
META_PATH = ARTIFACTS / "readiness_meta.json"

XGB_PARAMS = dict(n_estimators=1000, learning_rate=0.02, max_depth=3, min_child_weight=10,
                  subsample=0.85, colsample_bytree=0.85, reg_lambda=1.0,
                  eval_metric="logloss", random_state=SEED, n_jobs=2)


def classification_report(y, prob, threshold=0.5):
    pred = (prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"accuracy": accuracy_score(y, pred), "precision": precision_score(y, pred, zero_division=0),
            "recall": recall_score(y, pred, zero_division=0), "f1": f1_score(y, pred, zero_division=0),
            "roc_auc": roc_auc_score(y, prob), "confusion_matrix": {"tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn)}}


def _best_threshold(y, prob):
    grid = np.linspace(0.4, 0.6, 21)
    return float(max(grid, key=lambda t: f1_score(y, (prob >= t).astype(int))))


class ReadinessModel:
    def __init__(self, model=None, threshold=0.5, meta=None):
        self.model, self.threshold, self.meta = model, threshold, meta or {}

    # ------------------------------------------------------------------ training + evaluation
    @classmethod
    def train(cls, X: pd.DataFrame, y: np.ndarray):
        X = X[FEATURES]
        X_tmp, X_te, y_tmp, y_te = train_test_split(X, y, test_size=0.15, stratify=y, random_state=SEED)
        X_tr, X_va, y_tr, y_va = train_test_split(X_tmp, y_tmp, test_size=0.1765, stratify=y_tmp, random_state=SEED)

        model = xgb.XGBClassifier(**XGB_PARAMS, early_stopping_rounds=50)
        model.fit(X_tr, y_tr, eval_set=[(X_tr, y_tr), (X_va, y_va)], verbose=False)
        threshold = _best_threshold(y_va, model.predict_proba(X_va)[:, 1])
        history = model.evals_result()

        # baselines trained on the same split (median-impute GPA for models that need it)
        baselines = {
            "Logistic regression": make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), LogisticRegression(max_iter=2000)),
            "Random forest": make_pipeline(SimpleImputer(strategy="median"), RandomForestClassifier(n_estimators=300, min_samples_leaf=3, random_state=SEED)),
        }
        results = {"XGBoost": classification_report(y_te, model.predict_proba(X_te)[:, 1], threshold)}
        for name, b in baselines.items():
            b.fit(X_tr, y_tr)
            results[name] = classification_report(y_te, b.predict_proba(X_te)[:, 1], 0.5)

        # 5-fold cross-validation of the XGBoost configuration
        cv = {k: [] for k in ["accuracy", "precision", "recall", "f1", "roc_auc"]}
        for tr, va in StratifiedKFold(5, shuffle=True, random_state=SEED).split(X_tmp, y_tmp):
            m = xgb.XGBClassifier(**{**XGB_PARAMS, "n_estimators": model.best_iteration + 1})
            m.fit(X_tmp.iloc[tr], y_tmp[tr], verbose=False)
            rep = classification_report(y_tmp[va], m.predict_proba(X_tmp.iloc[va])[:, 1], threshold)
            for k in cv:
                cv[k].append(rep[k])

        prob_te = model.predict_proba(X_te)[:, 1]
        fpr, tpr, _ = roc_curve(y_te, prob_te)
        gain = model.get_booster().get_score(importance_type="gain")
        total = sum(gain.values()) or 1
        meta = {
            "features": FEATURES,
            "threshold": threshold,
            "best_iteration": int(model.best_iteration),
            "split": {"train": len(X_tr), "validation": len(X_va), "test": len(X_te), "positive_rate": float(np.mean(y))},
            "test_metrics": results,
            "cv_metrics": {k: {"mean": float(np.mean(v)), "std": float(np.std(v))} for k, v in cv.items()},
            "feature_importance": sorted([{"feature": f, "label": FEATURE_LABELS[f], "gain_share": gain.get(f, 0) / total} for f in FEATURES], key=lambda d: -d["gain_share"]),
            "roc_curve": {"fpr": fpr[::max(1, len(fpr) // 60)].round(4).tolist(), "tpr": tpr[::max(1, len(tpr) // 60)].round(4).tolist()},
            "learning_curve": {"train": history["validation_0"]["logloss"], "validation": history["validation_1"]["logloss"]},
        }
        return cls(model, threshold, meta)

    # ------------------------------------------------------------------ inference
    def predict(self, feats: dict) -> float:
        X = pd.DataFrame([feats])[FEATURES]
        return float(self.model.predict_proba(X)[0, 1])

    def predict_many(self, rows: list) -> np.ndarray:
        return self.model.predict_proba(pd.DataFrame(rows)[FEATURES])[:, 1]

    def explain(self, feats: dict):
        """Per-feature TreeSHAP contributions (log-odds) from XGBoost's pred_contribs."""
        dm = xgb.DMatrix(pd.DataFrame([feats])[FEATURES])
        contrib = self.model.get_booster().predict(dm, pred_contribs=True)[0]
        out = [{"feature": f, "label": FEATURE_LABELS[f], "value": feats[f], "contribution": float(c)}
               for f, c in zip(FEATURES, contrib[:-1])]
        return {"base_value": float(contrib[-1]), "contributions": sorted(out, key=lambda d: -abs(d["contribution"]))}

    # ------------------------------------------------------------------ persistence
    def save(self):
        MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.model.save_model(MODEL_PATH)
        META_PATH.write_text(json.dumps(self.meta, indent=2))

    @classmethod
    def load(cls):
        model = xgb.XGBClassifier()
        model.load_model(MODEL_PATH)
        meta = json.loads(META_PATH.read_text())
        return cls(model, meta["threshold"], meta)
