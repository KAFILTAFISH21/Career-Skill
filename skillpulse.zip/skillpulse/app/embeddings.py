"""Stage 3 - Skill embedding.

Every taxonomy skill is encoded with Sentence-BERT (all-MiniLM-L6-v2 by
default) from its name, category and synonyms. Vectors are L2-normalised so a
dot product equals cosine similarity.

Embeddings are computed once at training time and stored in
artifacts/skill_embeddings.npz, so the API only needs NumPy at runtime.
If sentence-transformers is unavailable (e.g. offline), a TF-IDF + LSA
fallback is used and the backend is recorded in the file.
"""
import numpy as np

from .config import ARTIFACTS, SBERT_MODEL
from .taxonomy import Taxonomy

EMB_PATH = ARTIFACTS / "skill_embeddings.npz"


def _normalise(m):
    return m / np.clip(np.linalg.norm(m, axis=1, keepdims=True), 1e-9, None)


class SkillEmbedder:
    def __init__(self, ids, matrix, backend):
        self.ids = list(ids)
        self.index = {s: i for i, s in enumerate(self.ids)}
        self.matrix = matrix.astype(np.float32)
        self.backend = backend

    # ------------------------------------------------------------------ build / load
    @classmethod
    def build(cls, tax: Taxonomy, model_name: str = SBERT_MODEL, allow_fallback=True):
        ids = list(tax.skills)
        texts = [tax.skills[s].embedding_text for s in ids]
        try:
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer(model_name)
            m = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
            backend = f"sentence-bert:{model_name}"
        except Exception as exc:  # noqa: BLE001
            if not allow_fallback:
                raise
            print(f"[embeddings] Sentence-BERT unavailable ({exc.__class__.__name__}); using TF-IDF + LSA fallback")
            from sklearn.decomposition import TruncatedSVD
            from sklearn.feature_extraction.text import TfidfVectorizer
            from scipy.sparse import hstack
            words = TfidfVectorizer(ngram_range=(1, 2)).fit_transform(texts)
            chars = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5)).fit_transform(texts)
            m = TruncatedSVD(n_components=48, random_state=0).fit_transform(hstack([words, chars]))
            backend = "tfidf-lsa-fallback"
        return cls(ids, _normalise(np.asarray(m)), backend)

    def save(self, path=EMB_PATH):
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(path, ids=np.array(self.ids), matrix=self.matrix, backend=np.array(self.backend))

    @classmethod
    def load(cls, path=EMB_PATH):
        d = np.load(path, allow_pickle=False)
        return cls(d["ids"].tolist(), d["matrix"], str(d["backend"]))

    # ------------------------------------------------------------------ queries
    def vectors(self, skill_ids):
        return self.matrix[[self.index[s] for s in skill_ids]]

    def similarity(self, a_ids, b_ids):
        """Cosine similarity matrix, shape (len(a_ids), len(b_ids))."""
        if not a_ids or not b_ids:
            return np.zeros((len(a_ids), len(b_ids)), dtype=np.float32)
        return self.vectors(a_ids) @ self.vectors(b_ids).T

    def most_similar(self, skill_id, k=5):
        sims = self.matrix @ self.matrix[self.index[skill_id]]
        order = np.argsort(-sims)
        return [(self.ids[i], float(sims[i])) for i in order if self.ids[i] != skill_id][:k]
