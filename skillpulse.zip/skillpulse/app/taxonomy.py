"""Skill taxonomy and role definitions (O*NET / ESCO-style)."""
import json
from dataclasses import dataclass, field
from functools import lru_cache

import pandas as pd

from .config import TAXONOMY_ROLES, TAXONOMY_SKILLS


@dataclass
class Skill:
    id: str
    name: str
    category: str
    aliases: list
    prerequisites: list
    hours_per_level: int
    project_idea: str
    onet_ref: str = ""
    esco_ref: str = ""

    @property
    def embedding_text(self):
        """Text fed to Sentence-BERT: name, category and synonyms give richer context."""
        return f"{self.name} ({self.category}). Also known as: {', '.join(self.aliases)}."


@dataclass
class Taxonomy:
    skills: dict = field(default_factory=dict)
    roles: dict = field(default_factory=dict)

    def name(self, sid):
        return self.skills[sid].name

    def role_title(self, rid):
        return self.roles[rid]["title"]


def _split(v):
    return [x.strip() for x in str(v).split("|") if x.strip() and x.strip() != "nan"]


@lru_cache(maxsize=1)
def load_taxonomy() -> Taxonomy:
    df = pd.read_csv(TAXONOMY_SKILLS).fillna("")
    skills = {
        r.skill_id: Skill(r.skill_id, r.name, r.category, _split(r.aliases), _split(r.prerequisites),
                          int(r.hours_per_level), r.project_idea, str(r.onet_ref), str(r.esco_ref))
        for r in df.itertuples()
    }
    roles = json.loads(TAXONOMY_ROLES.read_text())
    return Taxonomy(skills, roles)
