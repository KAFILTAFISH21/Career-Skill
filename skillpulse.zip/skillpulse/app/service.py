"""End-to-end analysis service used by the API (and usable from notebooks)."""
import math
from datetime import date

from .embeddings import SkillEmbedder
from .features import build_features
from .model import ReadinessModel
from .nlp import ResumeParser
from .recommend import add_impact, learning_plan, load_courses, rank_missing_skills
from .role_profiles import load_profiles
from .taxonomy import load_taxonomy


def verdict(p):
    if p >= 0.75:
        return "Job ready"
    if p >= 0.5:
        return "Almost ready"
    return "Needs development"


def _json_safe(obj):
    """Replace NaN/inf (e.g. a missing GPA) with None so responses are valid JSON."""
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    return obj


class ReadinessService:
    def __init__(self):
        self.tax = load_taxonomy()
        self.parser = ResumeParser(self.tax)
        self.emb = SkillEmbedder.load()
        self.profiles = load_profiles()
        self.model = ReadinessModel.load()
        self.courses = load_courses()

    # ------------------------------------------------------------------ building the profile
    def build_profile(self, payload: dict) -> dict:
        """Merge a parsed CV (if any) with manual form fields. Manual values win."""
        profile = {"skills": {}, "years_experience": 0, "internships": 0, "projects": 0, "certifications": 0,
                   "degree_level": 0, "degree_field": "", "gpa": None, "entities": []}
        if payload.get("resume_text"):
            profile.update(self.parser.parse(payload["resume_text"], today=date.today()))
            profile["skills"] = {k: v["level"] for k, v in profile["skills"].items()}
        for sid, lvl in (payload.get("skills") or {}).items():
            if sid in self.tax.skills:
                if lvl and int(lvl) > 0:
                    profile["skills"][sid] = int(lvl)
                else:
                    profile["skills"].pop(sid, None)
        for k in ["years_experience", "internships", "projects", "certifications", "degree_level", "degree_field", "gpa"]:
            if payload.get(k) not in (None, ""):
                profile[k] = payload[k]
        return profile

    # ------------------------------------------------------------------ analysis
    def readiness(self, profile, role_id):
        feats, gap = build_features(profile, self.profiles[role_id], self.emb)
        return self.model.predict(feats), feats, gap

    def analyze(self, payload: dict) -> dict:
        role_id = payload["target_role"]
        rp = self.profiles[role_id]
        profile = self.build_profile(payload)
        prob, feats, gap = self.readiness(profile, role_id)
        explanation = self.model.explain(feats)

        recs = rank_missing_skills(gap, self.tax, self.courses, top=int(payload.get("top_n", 8)))
        recs = add_impact(recs, profile, rp, self.emb, self.model, build_features)
        plan = learning_plan(recs, profile["skills"], self.tax, float(payload.get("hours_per_week", 10)))

        ranking = []
        for rid, prof in self.profiles.items():
            p, f, _ = self.readiness(profile, rid)
            ranking.append({"role_id": rid, "title": prof["title"], "readiness": p,
                            "coverage": f["weighted_coverage"], "similarity": f["semantic_similarity"]})
        ranking.sort(key=lambda d: -d["readiness"])

        return _json_safe({
            "target_role": {"role_id": role_id, "title": rp["title"], "min_years": rp["min_years"], "n_postings": rp["n_postings"]},
            "readiness": {"score": round(prob * 100, 1), "probability": prob, "verdict": verdict(prob),
                          "threshold": self.model.threshold},
            "features": feats,
            "explanation": explanation,
            "gap": gap,
            "recommendations": recs,
            "learning_plan": plan,
            "role_ranking": ranking,
            "profile": {k: v for k, v in profile.items() if k != "entities"} |
                       {"skills": [{"skill_id": s, "name": self.tax.name(s), "level": l} for s, l in profile["skills"].items()]},
            "entities": profile.get("entities", []),
            "embedding_backend": self.emb.backend,
        })

    def extract(self, text: str) -> dict:
        out = self.parser.parse(text, today=date.today())
        out["skills"] = list(out["skills"].values())
        return out
