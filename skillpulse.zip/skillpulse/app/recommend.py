"""Stage 6 - Recommendation generation.

Missing or partially covered skills are ranked by
    priority = (1 - coverage credit) x importance in the role x (0.5 + 0.5 x market demand)
and each is mapped to courses and a portfolio project. The XGBoost model is
also queried with the skill added, so every recommendation carries its
predicted readiness gain. A study plan orders the skills with Kahn's
topological sort over the prerequisite graph.
"""
import copy
import math

import pandas as pd

from .config import COURSES


def load_courses():
    try:
        return pd.read_csv(COURSES)
    except FileNotFoundError:
        return pd.DataFrame(columns=["skill_id", "provider", "title", "url", "est_hours", "cost"])


def rank_missing_skills(gap: dict, tax, courses: pd.DataFrame, top=8):
    recs = []
    for r in gap["skills"]:
        if r["status"] in ("matched", "semantic match"):
            continue
        priority = (1 - r["credit"]) * r["importance"] * (0.5 + 0.5 * r["demand"])
        s = tax.skills[r["skill_id"]]
        c = courses[courses.skill_id == r["skill_id"]].head(3).to_dict("records")
        target = 3 if not r["core"] else 4
        recs.append({
            "skill_id": r["skill_id"], "skill": s.name, "category": s.category, "status": r["status"],
            "importance": r["importance"], "demand": r["demand"], "frequency": r["frequency"],
            "priority": round(priority, 4), "target_level": target,
            "est_hours": target * s.hours_per_level, "courses": c, "project": s.project_idea,
            "related_skill_you_have": r["closest_user_skill"] if r["status"] == "partial" else None,
        })
    recs.sort(key=lambda d: -d["priority"])
    return recs[:top]


def add_impact(recs, profile, role_profile, emb, model, build_features):
    """Predicted readiness if the student acquired each recommended skill (counterfactual)."""
    base_feats, _ = build_features(profile, role_profile, emb)
    base = model.predict(base_feats)
    for rec in recs:
        p = copy.deepcopy(profile)
        p["skills"][rec["skill_id"]] = rec["target_level"]
        feats, _ = build_features(p, role_profile, emb)
        rec["readiness_after"] = model.predict(feats)
        rec["impact"] = rec["readiness_after"] - base
    return recs


def learning_plan(recs, user_skills: dict, tax, hours_per_week=10):
    need = {r["skill_id"]: {"priority": r["priority"], "prerequisite": False, "hours": r["est_hours"]} for r in recs}

    def add_prereqs(sid, pri):
        for q in tax.skills[sid].prerequisites:
            if q not in user_skills and q not in need:
                need[q] = {"priority": pri + 0.001, "prerequisite": True, "hours": 2 * tax.skills[q].hours_per_level}
                add_prereqs(q, pri)
            elif q in need:
                need[q]["priority"] = max(need[q]["priority"], pri + 0.001)

    for sid in list(need):
        add_prereqs(sid, need[sid]["priority"])

    pre = {s: [q for q in tax.skills[s].prerequisites if q in need] for s in need}
    indeg = {s: len(pre[s]) for s in need}
    ready, order = [s for s in need if indeg[s] == 0], []
    while ready:
        ready.sort(key=lambda s: -need[s]["priority"])
        cur = ready.pop(0)
        order.append(cur)
        for s in need:
            if cur in pre[s]:
                indeg[s] -= 1
                if indeg[s] == 0:
                    ready.append(s)

    week, plan = 0.0, []
    for sid in order:
        start = week
        week += need[sid]["hours"] / hours_per_week
        plan.append({"skill_id": sid, "skill": tax.name(sid), "hours": need[sid]["hours"],
                     "prerequisite": need[sid]["prerequisite"], "start_week": int(start) + 1,
                     "end_week": max(int(start) + 1, math.ceil(week - 1e-9)),
                     "milestone": tax.skills[sid].project_idea})
    return plan
