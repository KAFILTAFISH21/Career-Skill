"""Stage 5a - Feature engineering for the readiness model."""
import math

from .gap import analyze_gap

FEATURES = [
    "skill_overlap_pct",    # exact share of required skills present
    "weighted_coverage",    # importance-weighted semantic coverage
    "core_coverage",        # coverage of the role's core skills only
    "semantic_similarity",  # cosine(user skill vector, role vector)
    "years_experience",
    "experience_gap",       # years_experience - role's typical requirement
    "internships",
    "projects",
    "certifications",
    "education_level",      # 0 none, 1 diploma, 2 bachelor, 3 master, 4 PhD
    "education_match",      # 1 related field, 0.5 unknown, 0 unrelated
    "gpa",                  # normalised 0-1; missing is allowed (XGBoost handles NaN)
    "num_skills",
]

FEATURE_LABELS = {
    "skill_overlap_pct": "Skill overlap", "weighted_coverage": "Weighted skill coverage",
    "core_coverage": "Core skill coverage", "semantic_similarity": "Semantic similarity",
    "years_experience": "Years of experience", "experience_gap": "Experience vs requirement",
    "internships": "Internships", "projects": "Projects", "certifications": "Certifications",
    "education_level": "Education level", "education_match": "Education match", "gpa": "GPA",
    "num_skills": "Number of skills",
}


def education_match(field: str, role_profile: dict) -> float:
    if not field:
        return 0.5
    return 1.0 if field in role_profile["related_fields"] else 0.0


def build_features(profile: dict, role_profile: dict, emb, gap: dict | None = None):
    """profile: parsed CV dict (see nlp.ResumeParser.parse) with skills as {id: {level}} or {id: level}."""
    skills = {k: (v["level"] if isinstance(v, dict) else int(v)) for k, v in profile["skills"].items()}
    gap = gap or analyze_gap(skills, role_profile, emb)
    years = float(profile.get("years_experience", 0) or 0)
    gpa = profile.get("gpa")
    feats = {
        "skill_overlap_pct": gap["skill_overlap_pct"],
        "weighted_coverage": gap["weighted_coverage"],
        "core_coverage": gap["core_coverage"],
        "semantic_similarity": gap["semantic_similarity"],
        "years_experience": years,
        "experience_gap": years - role_profile["min_years"],
        "internships": float(profile.get("internships", 0)),
        "projects": float(profile.get("projects", 0)),
        "certifications": float(profile.get("certifications", 0)),
        "education_level": float(profile.get("degree_level", 0)),
        "education_match": education_match(profile.get("degree_field", ""), role_profile),
        "gpa": float(gpa) if gpa is not None else math.nan,
        "num_skills": float(len(skills)),
    }
    return feats, gap
